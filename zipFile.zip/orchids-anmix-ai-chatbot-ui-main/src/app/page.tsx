"use client";

import { useState, useRef, useEffect } from "react";
import { 
  Plus, 
  Settings, 
  Image as ImageIcon, 
  FileText, 
  File, 
  Trash2,
  Sparkles,
  ArrowUpRight,
  Zap,
  User
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import LightRays from "@/components/LightRays";
import ChatInput from "@/components/ChatInput";

interface FilePreview {
  type: "image" | "text" | "pdf";
  name: string;
  size: string;
  desc: string;
}

interface Message {
  id: number;
  role: "user" | "assistant";
  content: string;
  previews?: FilePreview[];
}

interface ChatSession {
  id: number;
  title: string;
  messages: Message[];
}

export default function AnmixDashboard() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      role: "assistant",
      content: "Welcome to ANMIX AI 4.0. How can I assist you today?",
    }
  ]);
  const [chatHistory, setChatHistory] = useState<ChatSession[]>([]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Auto scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTo({
        top: scrollRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  }, [messages, isTyping]);

  const handleSendMessage = async (customMsg?: string, previews?: FilePreview[]) => {
    const messageToSend = customMsg || input;
    if (!messageToSend.trim() && !previews) return;

    const userMsg: Message = {
      id: Date.now(),
      role: "user",
      content: messageToSend,
      previews: previews,
    };

    setMessages(prev => [...prev, userMsg]);
    if (!customMsg) setInput("");
    
    setIsTyping(true);

    // Simulate AI Response
    setTimeout(() => {
      const responses = [
        "I've analyzed your request and I'm ready to help. What specific details would you like to explore first?",
        "That's an interesting perspective. Based on current trends, we could approach this from several angles.",
        "Understood. I'm processing that information now. Would you like me to generate a summary or dive deeper into the technical aspects?",
        "I can certainly help with that. Here's what I've found so far...",
      ];
      
      const assistantMsg: Message = {
        id: Date.now() + 1,
        role: "assistant",
        content: responses[Math.floor(Math.random() * responses.length)],
      };

      // Add a file preview occasionally for flair
      if (Math.random() > 0.7) {
        assistantMsg.previews = [
          { type: "image", name: "generated-asset.png", size: "1.2 MB", desc: "AI generated visual." },
          { type: "text", name: "notes.md", size: "2 KB", desc: "Extracted insights." }
        ];
      }

      setMessages(prev => [...prev, assistantMsg]);
      setIsTyping(false);
    }, 1500);
  };

    const clearChat = () => {
      // Save current chat if there are messages (excluding initial assistant msg)
      if (messages.length > 1) {
        const newSession: ChatSession = {
          id: Date.now(),
          title: messages[1].content.slice(0, 30) + (messages[1].content.length > 30 ? "..." : ""),
          messages: [...messages]
        };
        setChatHistory(prev => [newSession, ...prev]);
      }
      
      setMessages([{
        id: Date.now(),
        role: "assistant",
        content: "Welcome to ANMIX AI 4.0. How can I assist you today?",
      }]);
    };

    const loadChat = (session: ChatSession) => {
      setMessages(session.messages);
    };


  return (
    <div className="flex h-screen text-slate-300 bg-[#06080F] font-sans selection:bg-blue-500/30 overflow-hidden relative">
      
      {/* BACKGROUND LIGHT RAYS */}
      <div className="absolute inset-0 z-0 opacity-40">
        <LightRays
          raysOrigin="top-center"
          raysColor="#4f46e5" // Blueish-violet
          raysSpeed={1.5}
          lightSpread={2.5}
          rayLength={3.5}
          followMouse={true}
          mouseInfluence={0.05}
          noiseAmount={0.02}
          distortion={0.1}
          pulsating={true}
          fadeDistance={1.2}
          saturation={0.6}
        />
      </div>

      {/* FIXED GRADIENT OVERLAYS */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-[1]">
        <div className="absolute top-[-20%] left-[-10%] w-[60%] h-[60%] bg-blue-600/10 rounded-full blur-[160px]" />
        <div className="absolute bottom-[-20%] right-[-10%] w-[60%] h-[60%] bg-fuchsia-600/10 rounded-full blur-[160px]" />
        <div className="absolute top-[40%] left-[50%] -translate-x-1/2 w-[40%] h-[40%] bg-indigo-500/5 rounded-full blur-[120px]" />
      </div>

      {/* LEFT SIDEBAR */}
      <aside className="w-72 flex flex-col z-20 bg-black/40 border-r border-white/5 backdrop-blur-3xl m-3 rounded-3xl">
        <div className="p-8 flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center overflow-hidden shadow-[0_0_20px_rgba(59,130,246,0.3)]">
            <img src="/logo.png" alt="ANMIX Logo" className="w-full h-full object-cover" />
          </div>
          <div>
            <h1 className="text-xl font-black tracking-tighter text-white">ANMIX</h1>
            <p className="text-[10px] text-blue-400/80 font-bold tracking-[0.2em] uppercase">Neural OS</p>
          </div>
        </div>

        <div className="px-6 mb-6">
          <button 
            onClick={clearChat}
            className="w-full bg-blue-600 hover:bg-blue-500 transition-all p-3.5 rounded-2xl flex items-center justify-center gap-3 text-sm font-bold text-white shadow-lg shadow-blue-600/20 group overflow-hidden relative"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/20 to-white/0 -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
            <Plus size={18} />
            <span>New Neural Chat</span>
          </button>
        </div>

          <div className="flex-1 overflow-y-auto px-4 space-y-1 scrollbar-hide">
            <div className="flex items-center justify-between px-4 mb-4 mt-2">
              <p className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">Workspace</p>
              <Sparkles size={12} className="text-blue-500" />
            </div>
            {chatHistory.length > 0 ? (
              chatHistory.map((chat) => (
                <button 
                  key={chat.id} 
                  onClick={() => loadChat(chat)}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl hover:bg-white/5 transition-all text-left group"
                >
                  <div className="w-2 h-2 rounded-full bg-slate-700 group-hover:bg-blue-400 transition-colors shrink-0" />
                  <span className="truncate text-xs text-slate-400 group-hover:text-slate-100 font-medium">{chat.title}</span>
                </button>
              ))
            ) : (
              <p className="text-[10px] text-slate-600 italic px-4">No past chats yet</p>
            )}
          </div>


        <div className="p-6 space-y-4">
          <div className="p-4 rounded-2xl bg-gradient-to-br from-indigo-500/10 to-blue-500/10 border border-indigo-500/20">
            <p className="text-xs font-bold text-slate-200 mb-1">Upgrade to Pro</p>
            <p className="text-[10px] text-slate-400 leading-relaxed mb-3">Access GPT-5 & Claude 4 models instantly.</p>
            <button className="w-full py-2 rounded-xl bg-white text-black text-[10px] font-black uppercase tracking-wider hover:bg-slate-200 transition-colors">
              Upgrade Now
            </button>
          </div>

          <div className="flex items-center gap-3 p-3 rounded-2xl bg-white/5 border border-white/5 cursor-pointer transition-all hover:border-white/20 group">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center border border-white/10 overflow-hidden relative shadow-lg">
              <img src="/logo.png" alt="User" className="w-full h-full object-cover" />
              <div className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 border-2 border-[#161C2C] rounded-full" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold text-slate-200 truncate">Alex Rivera</p>
              <p className="text-[10px] text-slate-500 font-medium">Neural Explorer</p>
            </div>
            <Settings size={16} className="text-slate-600 group-hover:text-white transition-colors" />
          </div>
        </div>
      </aside>

      {/* MAIN CHAT AREA */}
      <main className="flex-1 flex flex-col relative z-10 overflow-hidden bg-transparent">
        {/* Simple Header */}
        <header className="h-20 flex items-center justify-between px-10">
          <div className="flex items-center gap-4 group cursor-pointer">
            <div className="w-10 h-10 rounded-lg overflow-hidden border border-white/10 shadow-lg">
              <img src="/logo.png" alt="Logo" className="w-full h-full object-cover" />
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-black text-white tracking-widest uppercase">ANMIX 4.0</span>
              <div className="px-2 py-0.5 rounded-full bg-blue-500/10 border border-blue-500/20">
                <span className="text-[10px] font-bold text-blue-400">STABLE</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <button className="p-2.5 bg-white/5 border border-white/5 rounded-xl text-slate-400 hover:text-white hover:border-white/10 transition-all">
              <Sparkles size={18} />
            </button>
            <button 
              onClick={clearChat}
              className="p-2.5 bg-red-500/5 border border-red-500/10 rounded-xl text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition-all"
              title="Clear current chat"
            >
              <Trash2 size={18} />
            </button>
          </div>
        </header>

            {/* Conversation Scroll Area */}
            <div ref={scrollRef} className="flex-1 overflow-y-auto scrollbar-hide">
              <div className="max-w-3xl mx-auto px-4 py-2 space-y-1.5">
                <AnimatePresence mode="popLayout">
                  {messages.map((msg) => (
                    <motion.div 
                      layout
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.98 }}
                      key={msg.id} 
                      className={`flex gap-2 ${msg.role === "user" ? "flex-row-reverse" : "flex-row"}`}
                    >
                      <div className={`w-5 h-5 rounded-md flex-shrink-0 flex items-center justify-center border ${
                        msg.role === "assistant" 
                        ? "bg-gradient-to-br from-blue-600 to-indigo-600 border-white/20 text-white shadow-[0_0_8px_rgba(59,130,246,0.3)]" 
                        : "bg-white/5 border-white/10 text-slate-400 backdrop-blur-xl"
                      }`}>
                        {msg.role === "assistant" ? <Zap size={10} /> : <User size={10} />}
                      </div>
                      
                      <div className={`flex-1 space-y-1 ${msg.role === "user" ? "text-right" : "text-left"}`}>
                        <div className={`inline-block text-[11px] leading-relaxed max-w-[90%] selection:bg-blue-500/50 ${
                          msg.role === "user" 
                          ? "text-slate-100 bg-blue-600/20 border border-blue-500/30 px-2.5 py-1.5 rounded-lg rounded-tr-none shadow-md backdrop-blur-md" 
                          : "text-slate-200 bg-white/[0.04] border border-white/10 px-2.5 py-1.5 rounded-lg rounded-tl-none shadow-sm backdrop-blur-md"
                        }`}>
                          {msg.content}
                        </div>

                      
                      {msg.previews && (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2">
                          {msg.previews.map((file, fIdx) => (
                            <div 
                              key={fIdx} 
                              className="bg-white/5 rounded-xl p-2.5 flex items-center gap-2.5 border border-white/10 hover:border-blue-500/40 transition-all cursor-pointer group backdrop-blur-xl shadow-md"
                            >
                              <div className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${
                                file.type === "image" ? "bg-blue-500/20 text-blue-400" :
                                file.type === "text" ? "bg-emerald-500/20 text-emerald-400" :
                                "bg-amber-500/20 text-amber-400"
                              }`}>
                                {file.type === "image" && <ImageIcon size={18} />}
                                {file.type === "text" && <FileText size={18} />}
                                {file.type === "pdf" && <File size={18} />}
                              </div>
                              <div className="min-w-0 flex-1">
                                <p className="text-[10px] font-black truncate text-slate-200 uppercase tracking-tighter">{file.name}</p>
                                <p className="text-[8px] text-slate-500 font-bold">{file.size}</p>
                              </div>
                              <ArrowUpRight size={12} className="text-slate-600 group-hover:text-blue-400 transition-all" />
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </motion.div>
                ))}
                
                {isTyping && (
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="flex gap-3"
                  >
                    <div className="w-7 h-7 rounded-lg flex-shrink-0 flex items-center justify-center border bg-blue-600/20 border-blue-500/30 text-blue-400">
                      <Zap size={14} className="animate-pulse" />
                    </div>
                    <div className="flex items-center gap-1 mt-2">
                      <span className="w-1 h-1 bg-blue-500 rounded-full animate-bounce [animation-delay:-0.3s]" />
                      <span className="w-1 h-1 bg-indigo-500 rounded-full animate-bounce [animation-delay:-0.15s]" />
                      <span className="w-1 h-1 bg-fuchsia-500 rounded-full animate-bounce" />
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

        {/* Input Bar Area */}
        <div className="pb-10 px-10">
          <div className="max-w-3xl mx-auto relative group">
            <ChatInput 
              value={input}
              onChange={setInput}
              onSend={handleSendMessage}
              isGenerating={isTyping}
            />
            
            <p className="text-[10px] text-center text-slate-600 mt-6 uppercase tracking-[0.3em] font-black opacity-50">
              anmix ai can makes mistake so double check it.
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}
